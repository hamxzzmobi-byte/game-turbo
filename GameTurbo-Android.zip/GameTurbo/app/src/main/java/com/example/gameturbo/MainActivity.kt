package com.example.gameturbo

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** Daftar aplikasi terpasang. Pilih game -> panel turbo muncul -> game dibuka. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val list = ListView(this)
        list.setBackgroundColor(0xFF07150E.toInt())
        list.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(32, 24, 32, 24)
                }
                val icon = ImageView(this@MainActivity).apply {
                    setImageDrawable(apps[p].loadIcon(pm))
                    layoutParams = LinearLayout.LayoutParams(120, 120)
                }
                val name = TextView(this@MainActivity).apply {
                    text = apps[p].loadLabel(pm)
                    textSize = 18f
                    setTextColor(0xFFD8FFE7.toInt())
                    setPadding(32, 0, 0, 0)
                }
                row.addView(icon); row.addView(name)
                return row
            }
        }
        list.setOnItemClickListener { _, _, pos, _ -> launchWithTurbo(apps[pos]) }
        setContentView(list)
    }

    private fun launchWithTurbo(app: ResolveInfo) {
        // Izin "Tampil di atas aplikasi lain" wajib untuk panel mengambang
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin \"Tampil di atas aplikasi lain\" lalu pilih game lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        val launch = packageManager.getLaunchIntentForPackage(app.activityInfo.packageName)
        if (launch != null) startActivity(launch)
    }
}
