package com.example.gameturbo

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.IBinder
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Menampilkan panel turbo + crosshair + peredup layar di atas aplikasi lain. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private val d by lazy { resources.displayMetrics.density }
    private var panel: View? = null
    private var dim: View? = null
    private var crosshair: View? = null
    private var muted = false
    private var dimLevel = 0
    private val dimAlpha = intArrayOf(0, 90, 165)
    private lateinit var fpsText: TextView
    private var frames = 0
    private var lastNs = 0L
    private var running = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotification())
        if (panel == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            audio = getSystemService(AUDIO_SERVICE) as AudioManager
            addDim(); addCrosshair(); addPanel()
            startFpsLoop()
        }
        return START_STICKY
    }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    )

    private fun addDim() {
        dim = View(this).apply { setBackgroundColor(Color.argb(0, 0, 0, 0)) }
        wm.addView(dim, overlayParams(-1, -1, false))
    }

    private fun addCrosshair() {
        val v = object : View(this) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFF2D3D.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * d
            }
            override fun onDraw(c: Canvas) {
                val x = width / 2f; val y = height / 2f
                c.drawCircle(x, y, 10 * d, p)
                c.drawLine(x, 0f, x, height.toFloat(), p)
                c.drawLine(0f, y, width.toFloat(), y, p)
            }
        }
        v.visibility = View.GONE
        crosshair = v
        wm.addView(v, overlayParams((44 * d).toInt(), (44 * d).toInt(), false).apply { gravity = Gravity.CENTER })
    }

    private fun addPanel() {
        val bAudio = HexButton(this, "♪", "Audio").apply { active = true }
        val bBright = HexButton(this, "☀", "Cerah")
        val bCross = HexButton(this, "⊕", "Crosshair")
        val hz60 = HexButton(this, "60", "Hz").apply { active = true }
        val hz90 = HexButton(this, "", "90 Hz").apply { locked = true }
        val hz120 = HexButton(this, "", "120 Hz").apply { locked = true }
        val hz144 = HexButton(this, "", "144 Hz").apply { locked = true }

        bAudio.setOnClickListener {
            muted = !muted
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (muted) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
            bAudio.active = !muted
        }
        bBright.setOnClickListener {
            dimLevel = (dimLevel + 1) % dimAlpha.size
            dim?.setBackgroundColor(Color.argb(dimAlpha[dimLevel], 0, 0, 0))
            bBright.active = dimLevel > 0
        }
        bCross.setOnClickListener {
            val on = crosshair?.visibility != View.VISIBLE
            crosshair?.visibility = if (on) View.VISIBLE else View.GONE
            bCross.active = on
        }
        val locked = View.OnClickListener {
            Toast.makeText(this, "Layar ini tidak mendukung Hz tersebut", Toast.LENGTH_SHORT).show()
        }
        hz90.setOnClickListener(locked); hz120.setOnClickListener(locked); hz144.setOnClickListener(locked)

        fpsText = TextView(this).apply {
            setTextColor(0xFFD8FFE7.toInt()); textSize = 22f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            text = "LAYAR\n--"
        }
        val close = TextView(this).apply {
            text = "✕"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFE0242F.toInt()) }
            layoutParams = LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt())
            setOnClickListener { stopSelf() }
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            background = GradientDrawable().apply {
                setColor(0xEB05120B.toInt()); setStroke((3 * d).toInt(), 0xFF2CF07A.toInt()); cornerRadius = 18 * d
            }
            listOf(bAudio, bBright, bCross).forEach { addView(it) }
            addView(fpsText, LinearLayout.LayoutParams((90 * d).toInt(), -2))
            listOf(hz60, hz90, hz120, hz144).forEach { addView(it) }
            addView(close)
        }
        panel = row
        wm.addView(row, overlayParams(-2, -2, true).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (8 * d).toInt()
        })
    }

    // Catatan: ini mengukur laju refresh layar yang aktif (Choreographer),
    // BUKAN FPS game lain. Membaca FPS game lain butuh akses khusus (root/Shizuku).
    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!running) return
            if (lastNs == 0L) lastNs = ns
            frames++
            if (ns - lastNs >= 1_000_000_000L) {
                val hz = frames * 1_000_000_000.0 / (ns - lastNs)
                fpsText.text = "LAYAR\n${hz.toInt()}"
                frames = 0; lastNs = ns
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun startFpsLoop() { running = true; Choreographer.getInstance().postFrameCallback(frameCb) }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("turbo", "Game Turbo", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, "turbo")
            .setContentTitle("Game Turbo aktif")
            .setContentText("Panel turbo tampil di atas game")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
    }

    override fun onDestroy() {
        running = false
        if (muted) audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
        listOf(panel, dim, crosshair).forEach { v -> v?.let { runCatching { wm.removeView(it) } } }
        super.onDestroy()
    }
}
