package com.example.gameturbo

import android.content.Context
import android.graphics.*
import android.view.View

/** Tombol segi enam hijau dengan ikon (teks) dan label di bawahnya. */
class HexButton(ctx: Context, var icon: String, var label: String) : View(ctx) {
    var active = false
        set(v) { field = v; invalidate() }
    var locked = false
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val ico = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val path = Path()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((72 * d).toInt(), (92 * d).toInt())

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val r = 30 * d
        val cy = r + 4 * d
        path.reset()
        for (i in 0 until 6) {
            val a = Math.toRadians(60.0 * i - 90)
            val x = cx + r * Math.cos(a).toFloat()
            val y = cy + r * Math.sin(a).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        fill.color = if (active) 0xFF0F7A3D.toInt() else 0xFF0A2217.toInt()
        stroke.color = if (locked) 0xFF3C6B4F.toInt() else 0xFF2CF07A.toInt()
        c.drawPath(path, fill); c.drawPath(path, stroke)
        ico.textSize = 20 * d; ico.color = 0xFFD8FFE7.toInt()
        c.drawText(if (locked) "🔒" else icon, cx, cy + 7 * d, ico)
        txt.textSize = 11 * d
        txt.color = if (locked) 0xFF5E8A72.toInt() else if (active) 0xFFD8FFE7.toInt() else 0xFF7FB597.toInt()
        c.drawText(label, cx, height - 6 * d, txt)
    }
}
