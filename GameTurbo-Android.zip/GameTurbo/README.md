# Game Turbo (proyek Android, Kotlin)

Cara pakai:
1. Buka folder ini di Android Studio (File > Open). Biarkan Gradle sync selesai
   (Android Studio akan membuat Gradle wrapper otomatis).
2. Sambungkan HP (USB debugging) lalu Run, atau Build > Build APK(s).
3. Buka aplikasi, pilih game. Pertama kali akan diminta izin
   "Tampil di atas aplikasi lain". Aktifkan, lalu pilih game lagi.

Fitur: launcher daftar aplikasi, panel hex mengambang, crosshair, peredup layar,
senyapkan audio, tombol tutup. Hz 90/120/144 hanya tampilan terkunci.
Angka "LAYAR" = laju refresh layar, bukan FPS game lain.
